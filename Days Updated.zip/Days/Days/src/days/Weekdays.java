/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package days;

/**
 *
 * @author sivagamasrinivasan
 */
public class Weekdays 
{
  private enum day{Monday,Tuesday,Wednesday,Thursday,Friday,Saturday,Sunday}
  public void nameOfDay(String code)
     {
    switch(code.toUpperCase())
      {
      case "ONE":
        System.out.println(day.Monday);
        break;
      case "TWO":
        System.out.println(day.Tuesday);
        break;
      case "THREE":
        System.out.println(day.Wednesday);
        break;
      case "FOUR":
        System.out.println(day.Thursday);
        break;
      case "FIVE":
        System.out.println(day.Friday);
        break;
      case "SIX":
        System.out.println(day.Saturday);
        break;
      case "SEVEN":
        System.out.println(day.Sunday);
        break;
    }
  
}
}


